#define TYPE uint32_t
#define BWL(x) x ## l
#define BIOSCALL 0xb10d
#include "pci/writex.c"
