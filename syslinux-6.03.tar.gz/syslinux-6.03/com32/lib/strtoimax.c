#define TYPE intmax_t
#define NAME strtoimax
#include "strtox.c"
