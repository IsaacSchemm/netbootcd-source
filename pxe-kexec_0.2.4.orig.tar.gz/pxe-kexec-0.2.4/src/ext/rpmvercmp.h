#ifndef RPMVERCMP_H
#define RPMVERCMP_H

extern "C" {
    int rpmvercmp(const char * a, const char * b);
};

#endif /* RPMVERCMP_H */
